# -*- coding: utf-8 -*-
#
# Shortcut openEMS import
from __future__ import absolute_import

# try to import CSXCAD, e.g. make sure the (windows) dll path are set
import CSXCAD

from openEMS.openEMS import openEMS
